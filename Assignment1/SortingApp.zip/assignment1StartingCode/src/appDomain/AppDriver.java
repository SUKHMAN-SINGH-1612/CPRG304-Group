package appDomain;

import java.util.Scanner;
import shapes.*;
import shapeManager.*;
import sortingAlgorithms.*; // Assume your sorting algorithms are here
import java.util.Comparator;

public class AppDriver {
    public static void main(String[] args) {
        String fileName = null;
        String sortType = null;
        String compareType = null;
        Scanner scanner = new Scanner(System.in);

        // Parse command-line arguments in a flexible and case-insensitive manner
        for (int i = 0; i < args.length; i++) {
            String arg = args[i].toLowerCase();

            if (arg.startsWith("-f")) { // Handle both -f and -F
                if (arg.length() > 2) {
                    fileName = arg.substring(2); // Handle -ffilename case
                } else if (i + 1 < args.length) {
                    fileName = args[++i];
                }
            } else if (arg.startsWith("-s")) {
                if (arg.length() > 2) {
                    sortType = arg.substring(2);
                } else if (i + 1 < args.length) {
                    sortType = args[++i].toLowerCase();
                }
            } else if (arg.startsWith("-t")) {
                if (arg.length() > 2) {
                    compareType = arg.substring(2);
                } else if (i + 1 < args.length) {
                    compareType = args[++i].toLowerCase();
                }
            }
        }

        // Validate inputs and prompt for missing values
        if (fileName == null) {
            System.out.println("Please enter the file path:");
            fileName = scanner.nextLine().trim();
        }

        if (compareType == null || !compareType.matches("[vha]")) {
            System.out.println("Invalid or missing compare type. Enter 'v' (volume), 'h' (height), or 'a' (base area):");
            compareType = scanner.nextLine().trim().toLowerCase();
        }

        if (sortType == null || !sortType.matches("[bsimqz]")) {
            System.out.println("Invalid or missing sorting algorithm. Choose from: b (Bubble), s (Selection), i (Insertion), m (Merge), q (Quick), z (Custom):");
            sortType = scanner.nextLine().trim().toLowerCase();
        }

        try {
            // Load shapes from the file
            Shape[] shapes = ShapeFileReader.readShapesFromFile(fileName);
            System.out.println("Successfully loaded " + shapes.length + " shapes.");

            // Create comparator
            Comparator<Shape> comparator = new ShapeComparator(compareType);

            // Sort and benchmark
            long startTime = System.nanoTime();
            switch (sortType) {
                case "b": BubbleSort.sort(shapes, comparator); break;
                case "i": InsertionSort.sort(shapes, comparator); break;
                case "s": SelectionSort.sort(shapes, comparator); break;
                case "m": MergeSort.sort(shapes, comparator); break;
                case "q": QuickSort.sort(shapes, comparator); break;
                case "z": CountingSort.sort(shapes); break; // Custom sorting
                default: throw new IllegalArgumentException("Invalid sorting algorithm: " + sortType);
            }
            long endTime = System.nanoTime();
            double duration = (endTime - startTime) / 1_000_000.0;

            // Print results
            printSortedResults(shapes);
            System.out.printf("%s Sort run time was: %.3f milliseconds%n", getAlgorithmName(sortType), duration);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } finally {
            scanner.close();
        }
    }

    private static void printSortedResults(Shape[] shapes) {
        System.out.println("First element: " + shapes[0]);
        for (int i = 999; i < shapes.length; i += 1000) {
            System.out.println((i+1) + "-th element: " + shapes[i]);
        }
        System.out.println("Last element: " + shapes[shapes.length - 1]);
    }

    private static String getAlgorithmName(String sortType) {
        switch (sortType) {
            case "b": return "Bubble";
            case "i": return "Insertion";
            case "s": return "Selection";
            case "m": return "Merge";
            case "q": return "Quick";
            case "z": return "Custom"; // Replace with your algorithm name
            default: return "Unknown";
        }
    }
}
