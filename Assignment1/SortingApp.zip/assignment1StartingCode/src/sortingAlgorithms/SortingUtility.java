package sortingAlgorithms;
public class SortingUtility
{
	// IMPORTANT
	// Algorithms must use comparable for height and comparators for other orders
}
